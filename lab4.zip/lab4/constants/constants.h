enum PieceType{
  ROOK,
  KNIGHT,
  BISHOP,
  QUEEN,
  KING,
  PAWN
};

const int BOARD_SIZE = 8;
