var searchData=
[
  ['queen_0',['Queen',['../classQueen.html',1,'']]]
];
