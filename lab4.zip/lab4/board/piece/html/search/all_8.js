var searchData=
[
  ['setup_0',['Setup',['../classSetup.html',1,'']]]
];
