var searchData=
[
  ['gettreathenedpositions_0',['getTreathenedPositions',['../classKnight.html#a361e4eced126b52c215ba18c953455fb',1,'Knight::getTreathenedPositions()'],['../classRook.html#ae292f0c7d186e103839bba6a2f7bab19',1,'Rook::getTreathenedPositions()'],['../classBishop.html#aa3e3f956f5444e38a94f0d7cf97e32b9',1,'Bishop::getTreathenedPositions()'],['../classPawn.html#a38e411172c17863469122fdc8020188a',1,'Pawn::getTreathenedPositions()']]]
];
