var searchData=
[
  ['create_0',['create',['../classPieceFactory.html#a68538ef56290d958d6bc7759464dad5b',1,'PieceFactory']]]
];
