var searchData=
[
  ['bishop_0',['Bishop',['../classBishop.html',1,'']]]
];
