var indexSectionsWithContent =
{
  0: "bcgkmpqrs",
  1: "bckmpqrs",
  2: "cg"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

