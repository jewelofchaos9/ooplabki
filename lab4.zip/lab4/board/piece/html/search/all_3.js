var searchData=
[
  ['king_0',['King',['../classKing.html',1,'']]],
  ['knight_1',['Knight',['../classKnight.html',1,'']]]
];
